#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define SIZE 16
#define ENTER '\n'
#define MAX 37767

int pokracuj() {
    printf("Pro pokracovani stiskni ENTER!\n");
    if (getchar() == ENTER) {
        return 1;
    } else {
        return 0;
    }
}

void naplnPole(int *arr) {
    for (int i = 0; i < SIZE; ++i) {
        arr[i] = rand() % 2;
    }
}

void vynulujPole(int *arr) {
    for (int i = 0; i < SIZE; ++i) {
        arr[i] = 0;
    }
}

void prevodBin(int *arr, int cislo) {
    vynulujPole(arr);
    int i = SIZE - 1;
    while (cislo > 0 && i >= 0) {
        arr[i] = cislo % 2;
        cislo /= 2;
        i--;
    }
}

void vypisPole2(const int *arr, int cislo) {
    printf("%d = ", cislo);
    for (int i = 0; i < SIZE; ++i) {
        printf("%d", arr[i]);
    }
    printf("\n");
}

unsigned int prevodDes(const int *arr) {
    unsigned int cislo = 0;
    for (int i = 0; i < SIZE; ++i) {
        cislo += arr[i] * (unsigned int) pow(2, SIZE - i - 1);
    }
    return cislo;
}

void vypisPole(const int *arr) {
    for (int i = 0; i < SIZE; ++i) {
        printf("%d", arr[i]);
    }
    printf(" = %u\n", prevodDes(arr));
}

int vstup() {
    int cislo;
    int pocetZnaku;
    do {
        printf("Zadej cislo v intervalu od 0 do %d:", MAX);
        scanf("%d", &cislo);
        pocetZnaku = 0;
        while (getchar() != ENTER) {
            pocetZnaku++;
        }
        if (pocetZnaku != 0) {
            printf("Nebylo zadano cele cislo, zadej znovu.\n");
        } else if (cislo < 0 || cislo > MAX) {
            printf("Cislo nebylo zadano v intervalu, zadej znovu.\n");
        }
    } while (pocetZnaku != 0 || cislo < 0 || cislo > MAX);
    return cislo;
}

int main() {
    int cislo;
    int array[SIZE];
    srand((unsigned) time(NULL));
    do {
        naplnPole(array);
        vypisPole(array);
        cislo = vstup();
        prevodBin(array, cislo);
        vypisPole2(array, cislo);
    } while (pokracuj());
    return 0;
}


